const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const path = require('path');
const axios = require('axios');
const cookieParser = require('cookie-parser');
const fs = require('fs');

const app = express();
const PORT = process.env.PORT || 3000;
const SECRET_KEY = process.env.SECRET_KEY || 'KRASTY_FORTRESS_SECRET_2024';
const SYNC_TOKEN = process.env.SYNC_TOKEN || 'fortress_token_2024';

app.use(express.json({ limit: '50mb' }));
app.use(cookieParser());
app.use(express.static('public'));

// Database Setup
const dbPath = path.join(__dirname, 'db', 'krasty.db');
const db = new sqlite3.Database(dbPath);

db.serialize(() => {
    db.run("CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE, password TEXT, quota INTEGER DEFAULT 53687091200)");
    db.run("CREATE TABLE IF NOT EXISTS agents (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, name TEXT, avatar_url TEXT, prompt TEXT, FOREIGN KEY(user_id) REFERENCES users(id))");
    db.run("CREATE TABLE IF NOT EXISTS chats (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, title TEXT, history TEXT, timestamp DATETIME DEFAULT CURRENT_TIMESTAMP)");
});

// --- FORTRESS SYNC & HEALTH ENDPOINTS ---
app.get('/api/health', (req, res) => res.json({ status: 'ok', node: process.env.NODE_TYPE || 'local' }));

app.post('/api/sync/upload', (req, res) => {
    const token = req.headers['x-sync-token'];
    if (token !== SYNC_TOKEN) return res.status(403).json({ error: 'Token de sincronización inválido' });

    const { db: dbBase64 } = req.body;
    try {
        const buffer = Buffer.from(dbBase64, 'base64');
        fs.writeFileSync(dbPath + '.sync', buffer);
        // Lógica de swap para producción: se recomienda reiniciar o cerrar conexión a DB
        res.json({ message: 'Datos de respaldo recibidos correctamente' });
    } catch (e) {
        res.status(500).json({ error: 'Error al procesar la sincronización' });
    }
});

// --- CHAT & AUTH LOGIC ---
const authenticateToken = (req, res, next) => {
    const token = req.cookies.token;
    if (!token) return next();
    jwt.verify(token, SECRET_KEY, (err, user) => {
        if (err) return next();
        req.user = user;
        next();
    });
};

app.post('/api/chat', authenticateToken, async (req, res) => {
    const { message, provider, endpoint, model, apiKey } = req.body;
    try {
        let response;
        if (provider === 'chutes') {
            const resChutes = await axios.post('https://llm.chutes.ai/v1/chat/completions', {
                model: model || 'deepseek-ai/DeepSeek-V3',
                messages: [{ role: "user", content: message }]
            }, { headers: { 'Authorization': `Bearer ${apiKey}` } });
            response = resChutes.data.choices[0].message.content;
        } else {
            const resLocal = await axios.post(endpoint || 'http://localhost:11434/v1/chat/completions', {
                model: model || 'llama3',
                messages: [{ role: "user", content: message }]
            });
            response = resLocal.data.choices[0].message.content;
        }
        res.json({ response });
    } catch (error) {
        res.status(500).json({ response: "Error de conexión: " + error.message });
    }
});

app.post('/api/register', async (req, res) => {
    const { username, password } = req.body;
    const hashedPassword = await bcrypt.hash(password, 10);
    db.run('INSERT INTO users (username, password) VALUES (?, ?)', [username, hashedPassword], (err) => {
        if (err) return res.status(400).send('User already exists');
        res.status(201).send('User created');
    });
});

app.post('/api/login', async (req, res) => {
    const { username, password } = req.body;
    db.get('SELECT * FROM users WHERE username = ?', [username], async (err, user) => {
        if (!user || !(await bcrypt.compare(password, user.password))) return res.status(401).send('Invalid credentials');
        const token = jwt.sign({ id: user.id, username: user.username }, SECRET_KEY);
        res.cookie('token', token, { httpOnly: true }).send({ message: 'Logged in', username: user.username });
    });
});

app.listen(PORT, () => console.log(`Krasty Kebab Fortress running on port ${PORT}`));
