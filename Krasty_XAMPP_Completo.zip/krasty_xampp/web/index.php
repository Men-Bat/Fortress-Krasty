<?php
declare(strict_types=1);
require dirname(__DIR__) . '/app/bootstrap.php';

$route = trim((string)($_GET['route'] ?? ''), '/');
$method = strtoupper((string)($_SERVER['REQUEST_METHOD'] ?? 'GET'));

function form_input(string $name, string $type = 'text', string $label = '', string $value = '', string $extra = ''): string {
    return '<label>' . escape_html($label ?: $name) . '<input name="' . escape_html($name) . '" type="' . escape_html($type) . '" value="' . escape_html($value) . '" ' . $extra . ' required></label>';
}

function flash(string $message): void { $_SESSION['flash'] = $message; }
function flash_html(): string {
    $message = (string)($_SESSION['flash'] ?? '');
    unset($_SESSION['flash']);
    return $message ? '<div class="flash">' . escape_html($message) . '</div>' : '';
}

if ($route === '') {
    $user = current_user();
    if ($user) redirect_to($user['username'] . '/Krasty/');
    $body = '<section class="hero"><h1>Tu Krasty privado, en tu propio servidor</h1><p>Registra tu cuenta, conserva tus archivos en una carpeta separada y conversa con el modelo local configurado por el administrador.</p><div class="actions"><a class="button" href="' . escape_html(base_url('register')) . '">Crear cuenta</a><a class="button secondary" href="' . escape_html(base_url('login')) . '">Entrar</a></div></section>';
    render_page('Inicio', $body);
}

if ($route === 'register') {
    if ($method === 'POST') {
        require_csrf();
        $username = strtolower(trim((string)($_POST['username'] ?? '')));
        $password = (string)($_POST['password'] ?? '');
        $adminToken = (string)($_POST['admin_token'] ?? '');
        if (!is_valid_username($username)) {
            flash('El nombre debe tener entre 3 y 32 caracteres y solo letras, números, guion o guion bajo.');
            redirect_to('register');
        }
        if (strlen($password) < 12 || strlen($password) > 128) {
            flash('La contraseña debe tener entre 12 y 128 caracteres.');
            redirect_to('register');
        }
        $existingUsers = (int)$db->query('SELECT COUNT(*) FROM users')->fetchColumn();
        if ($existingUsers === 0 && !hash_equals((string)$config['first_admin_token'], $adminToken)) {
            flash('Para la primera cuenta debes introducir el token de primer administrador definido en config.php.');
            redirect_to('register');
        }
        $isAdmin = $existingUsers === 0 ? 1 : 0;
        try {
            $statement = $db->prepare('INSERT INTO users (username, password_hash, is_admin, quota_bytes) VALUES (?, ?, ?, ?)');
            $statement->execute([$username, password_hash($password, PASSWORD_DEFAULT), $isAdmin, (int)$config['quota_bytes']]);
            $id = (int)$db->lastInsertId();
            $user = ['id' => $id, 'username' => $username];
            user_folder($user);
            log_action($id, 'registro', $isAdmin ? 'Primera cuenta administradora creada' : 'Cuenta creada');
            session_regenerate_id(true);
            $_SESSION['user_id'] = $id;
            flash($isAdmin ? 'Cuenta administradora creada. Guarde y sustituya first_admin_token en config.php.' : 'Cuenta creada correctamente.');
            redirect_to($username . '/Krasty/');
        } catch (PDOException $exception) {
            flash('Ese nombre de usuario ya está en uso.');
            redirect_to('register');
        }
    }
    $body = '<section class="card narrow"><h1>Crear cuenta</h1>' . flash_html() . '<form method="post" autocomplete="on">' .
        form_input('username', 'text', 'Nombre de usuario') .
        form_input('password', 'password', 'Contraseña (mínimo 12 caracteres)', '', 'minlength="12" maxlength="128"') .
        '<label>Token de primer administrador <span class="hint">Solo para la primera cuenta; después puede dejarlo vacío.</span><input name="admin_token" type="password"></label>' .
        '<input type="hidden" name="csrf" value="' . escape_html(csrf_token()) . '"><button type="submit">Crear mi Krasty</button></form><p class="muted">Tu dirección será: <code>web.com/tu_usuario/Krasty/</code></p></section>';
    render_page('Registro', $body);
}

if ($route === 'login') {
    if ($method === 'POST') {
        require_csrf();
        $username = strtolower(trim((string)($_POST['username'] ?? '')));
        $password = (string)($_POST['password'] ?? '');
        $statement = $db->prepare('SELECT id, username, password_hash FROM users WHERE username = ?');
        $statement->execute([$username]);
        $record = $statement->fetch();
        if (!$record || !password_verify($password, (string)$record['password_hash'])) {
            usleep(300000);
            flash('Usuario o contraseña incorrectos.');
            redirect_to('login');
        }
        session_regenerate_id(true);
        $_SESSION['user_id'] = (int)$record['id'];
        log_action((int)$record['id'], 'inicio_sesion');
        redirect_to($record['username'] . '/Krasty/');
    }
    $body = '<section class="card narrow"><h1>Entrar</h1>' . flash_html() . '<form method="post">' .
        form_input('username', 'text', 'Nombre de usuario') . form_input('password', 'password', 'Contraseña') .
        '<input type="hidden" name="csrf" value="' . escape_html(csrf_token()) . '"><button type="submit">Entrar a mi Krasty</button></form></section>';
    render_page('Entrar', $body);
}

if ($route === 'logout') {
    $user = current_user();
    if ($user) log_action((int)$user['id'], 'cierre_sesion');
    $_SESSION = [];
    session_destroy();
    redirect_to('');
}

if ($route === 'admin') {
    $admin = require_admin();
    $users = $db->query('SELECT u.id, u.username, u.is_admin, u.created_at, COALESCE(SUM(f.size_bytes),0) AS used FROM users u LEFT JOIN files f ON f.user_id=u.id GROUP BY u.id ORDER BY u.created_at DESC')->fetchAll();
    $rows = '';
    foreach ($users as $account) {
        $rows .= '<tr><td>' . escape_html($account['username']) . '</td><td>' . ((int)$account['is_admin'] ? 'Sí' : 'No') . '</td><td>' . escape_html(number_format((int)$account['used'] / 1024 / 1024, 1)) . ' MB</td><td>' . escape_html($account['created_at']) . '</td></tr>';
    }
    $body = '<section class="card"><h1>Administración</h1><p>Solo los administradores ven este resumen. Los usuarios nunca acceden a las carpetas ni a los archivos de otros usuarios.</p><table><thead><tr><th>Usuario</th><th>Admin</th><th>Uso</th><th>Registro</th></tr></thead><tbody>' . $rows . '</tbody></table></section>';
    render_page('Administración', $body, $admin);
}

$parts = explode('/', $route);
if (count($parts) >= 2 && $parts[1] === 'Krasty') {
    $requestedUsername = strtolower($parts[0]);
    $section = $parts[2] ?? '';
    $user = require_login();
    if ($requestedUsername !== $user['username'] && (int)$user['is_admin'] !== 1) {
        http_response_code(403);
        render_page('Acceso denegado', '<section class="card"><h1>Acceso denegado</h1><p>Solo puedes abrir tu propio espacio Krasty.</p></section>', $user);
    }
    $statement = $db->prepare('SELECT id, username, is_admin, quota_bytes FROM users WHERE username = ?');
    $statement->execute([$requestedUsername]);
    $owner = $statement->fetch();
    if (!$owner) {
        http_response_code(404);
        render_page('No encontrado', '<section class="card"><h1>Usuario no encontrado</h1></section>', $user);
    }

    if ($section === 'download' && isset($parts[3])) {
        $fileId = (int)$parts[3];
        $statement = $db->prepare('SELECT * FROM files WHERE id = ? AND user_id = ?');
        $statement->execute([$fileId, $owner['id']]);
        $file = $statement->fetch();
        if (!$file) { http_response_code(404); exit('Archivo no encontrado.'); }
        $filePath = user_folder($owner) . DIRECTORY_SEPARATOR . 'files' . DIRECTORY_SEPARATOR . $file['stored_name'];
        if (!is_file($filePath)) { http_response_code(404); exit('El archivo no está disponible.'); }
        header('Content-Type: ' . $file['mime_type']);
        header('Content-Disposition: attachment; filename="' . rawurlencode($file['original_name']) . '"');
        header('Content-Length: ' . filesize($filePath));
        readfile($filePath);
        exit;
    }

    if ($section === 'upload' && $method === 'POST') {
        require_csrf();
        if (!isset($_FILES['document']) || $_FILES['document']['error'] !== UPLOAD_ERR_OK) {
            flash('No se recibió el archivo. Revise el límite de subida configurado en php.ini.');
            redirect_to($owner['username'] . '/Krasty/');
        }
        $upload = $_FILES['document'];
        $size = (int)$upload['size'];
        if ($size < 1 || $size > 2 * 1024 * 1024 * 1024) {
            flash('El archivo no es válido o supera el límite de 2 GB por subida.');
            redirect_to($owner['username'] . '/Krasty/');
        }
        $currentUse = used_bytes((int)$owner['id']);
        if ($currentUse + $size > (int)$owner['quota_bytes']) {
            flash('No hay espacio suficiente en tu cuota de 50 GB.');
            redirect_to($owner['username'] . '/Krasty/');
        }
        $originalName = basename((string)$upload['name']);
        $storedName = bin2hex(random_bytes(16)) . '-' . preg_replace('/[^a-zA-Z0-9._-]/', '_', $originalName);
        $mime = (new finfo(FILEINFO_MIME_TYPE))->file((string)$upload['tmp_name']) ?: 'application/octet-stream';
        $destination = user_folder($owner) . DIRECTORY_SEPARATOR . 'files' . DIRECTORY_SEPARATOR . $storedName;
        if (!move_uploaded_file((string)$upload['tmp_name'], $destination)) {
            flash('No se pudo guardar el archivo.');
            redirect_to($owner['username'] . '/Krasty/');
        }
        $statement = $db->prepare('INSERT INTO files (user_id, original_name, stored_name, size_bytes, mime_type) VALUES (?, ?, ?, ?, ?)');
        $statement->execute([$owner['id'], $originalName, $storedName, $size, $mime]);
        log_action((int)$owner['id'], 'archivo_subido', $originalName);
        flash('Archivo guardado correctamente.');
        redirect_to($owner['username'] . '/Krasty/');
    }

    if ($section === 'chat' && $method === 'POST') {
        require_csrf();
        $message = trim((string)($_POST['message'] ?? ''));
        if ($message === '' || strlen($message) > 48000) {
            flash('El mensaje debe tener entre 1 y 12.000 caracteres.');
            redirect_to($owner['username'] . '/Krasty/');
        }
        $statement = $db->prepare('INSERT INTO conversations (user_id, role, content) VALUES (?, ?, ?)');
        $statement->execute([$owner['id'], 'user', $message]);
        $answer = model_response($message);
        $statement->execute([$owner['id'], 'assistant', $answer]);
        log_action((int)$owner['id'], 'mensaje_chat');
        redirect_to($owner['username'] . '/Krasty/');
    }

    $statement = $db->prepare('SELECT id, original_name, size_bytes, created_at FROM files WHERE user_id = ? ORDER BY created_at DESC');
    $statement->execute([$owner['id']]);
    $files = $statement->fetchAll();
    $fileRows = '';
    foreach ($files as $file) {
        $fileRows .= '<li><a href="' . escape_html(base_url($owner['username'] . '/Krasty/download/' . $file['id'])) . '">' . escape_html($file['original_name']) . '</a><span>' . escape_html(number_format((int)$file['size_bytes'] / 1024 / 1024, 2)) . ' MB · ' . escape_html($file['created_at']) . '</span></li>';
    }
    if ($fileRows === '') $fileRows = '<li class="muted">Aún no has subido archivos.</li>';
    $statement = $db->prepare('SELECT role, content, created_at FROM conversations WHERE user_id = ? ORDER BY id DESC LIMIT 30');
    $statement->execute([$owner['id']]);
    $messages = array_reverse($statement->fetchAll());
    $chatHtml = '';
    foreach ($messages as $message) {
        $chatHtml .= '<div class="message ' . ($message['role'] === 'user' ? 'user' : 'assistant') . '"><strong>' . ($message['role'] === 'user' ? 'Tú' : 'Krasty') . '</strong><p>' . nl2br(escape_html($message['content'])) . '</p></div>';
    }
    if ($chatHtml === '') $chatHtml = '<p class="muted">Escribe tu primera petición al modelo local.</p>';
    $used = used_bytes((int)$owner['id']);
    $quota = (int)$owner['quota_bytes'];
    $percentage = min(100, $quota > 0 ? ($used / $quota * 100) : 0);
    $body = '<section class="dashboard"><div class="card welcome"><h1>Hola, ' . escape_html($owner['username']) . '</h1><p>Tu dirección privada es <code>' . escape_html(base_url($owner['username'] . '/Krasty/')) . '</code>.</p><div class="quota"><div><strong>Espacio privado</strong><span>' . escape_html(number_format($used / 1024 / 1024 / 1024, 2)) . ' GB de ' . escape_html(number_format($quota / 1024 / 1024 / 1024, 0)) . ' GB</span></div><div class="progress"><i style="width:' . escape_html((string)$percentage) . '%"></i></div></div></div><div class="columns"><section class="card"><h2>Chat con tu modelo local</h2><div class="chat">' . $chatHtml . '</div><form method="post" action="' . escape_html(base_url($owner['username'] . '/Krasty/chat')) . '"><textarea name="message" placeholder="Escribe aquí tu petición..." maxlength="12000" required></textarea><input type="hidden" name="csrf" value="' . escape_html(csrf_token()) . '"><button type="submit">Enviar</button></form></section><section class="card"><h2>Mis archivos</h2>' . flash_html() . '<form method="post" enctype="multipart/form-data" action="' . escape_html(base_url($owner['username'] . '/Krasty/upload')) . '"><input type="file" name="document" required><input type="hidden" name="csrf" value="' . escape_html(csrf_token()) . '"><button type="submit">Guardar archivo</button></form><ul class="files">' . $fileRows . '</ul></section></div></section>';
    render_page('Mi Krasty', $body, $user);
}

http_response_code(404);
render_page('No encontrado', '<section class="card"><h1>Página no encontrada</h1><p>Comprueba la dirección o vuelve al inicio.</p></section>', current_user());
