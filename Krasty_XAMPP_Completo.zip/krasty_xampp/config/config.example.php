<?php
/**
 * Copie este archivo como config.php y complete los valores indicados.
 * config.php nunca debe quedar dentro de htdocs ni subirse a un repositorio.
 */
return [
    'app_name' => 'Krasty Kebab Local',

    // Carpeta fuera de C:\xampp\htdocs. Ejemplo: C:\KrastyData
    'data_root' => 'C:/KrastyData',

    // Debe ser una cadena larga y aleatoria. Genere una nueva con:
    // php -r "echo bin2hex(random_bytes(32)), PHP_EOL;"
    'app_secret' => 'REEMPLACE_ESTO_POR_UN_SECRETO_LARGO_Y_ALEATORIO',

    // Token usado únicamente para designar el primer administrador al registrar la primera cuenta.
    // Después de crear ese administrador, sustituya el valor por otro secreto y guárdelo fuera de línea.
    'first_admin_token' => 'CAMBIE_ESTE_TOKEN_ANTES_DE_ABRIR_EL_REGISTRO',

    // 50 GiB por usuario. El tamaño se calcula al subir archivos.
    'quota_bytes' => 50 * 1024 * 1024 * 1024,

    // Use true cuando la página se abra por HTTPS con certificado válido.
    'cookie_secure' => true,

    // Ajuste si la aplicación se publica dentro de una subcarpeta.
    // Ejemplos: '' para https://web.com/ ; '/krasty' para https://web.com/krasty/
    'base_path' => '',

    // Modelo local opcional. Solo se intenta usar desde el servidor; el navegador no decide la URL.
    'model' => [
        'enabled' => true,
        'provider' => 'ollama',
        'ollama_url' => 'http://127.0.0.1:11434/api/generate',
        'default_model' => 'llama3',
        'timeout_seconds' => 120,
    ],

    // Segundo ordenador: carpeta SMB compartida. El script de Windows la usará como destino.
    'secondary_backup_share' => '\\\\ORDENADOR-RESPALDO\\KrastyBackups',

    // Tercera copia: se genera un ZIP cifrado local. La subida a un hosting web es deliberadamente manual
    // salvo que su proveedor ofrezca WebDAV/SFTP. Nunca incluya este secreto dentro de una web pública.
    'vault_passphrase' => 'REEMPLACE_POR_UNA_FRASE_LARGA_GUARDADA_FUERA_DE_LINEA',
];
