<?php
declare(strict_types=1);

$configFile = dirname(__DIR__) . DIRECTORY_SEPARATOR . 'config' . DIRECTORY_SEPARATOR . 'config.php';
if (!is_file($configFile)) {
    http_response_code(500);
    exit('Falta config/config.php. Copie config/config.example.php como config.php y complételo.');
}

$config = require $configFile;
if (!is_array($config) || strlen((string)($config['app_secret'] ?? '')) < 32 || str_contains((string)($config['app_secret'] ?? ''), 'REEMPLACE_')) {
    http_response_code(500);
    exit('La configuración no es válida. Revise app_secret en config.php.');
}

$dataRoot = rtrim((string)$config['data_root'], '/\\');
foreach ([$dataRoot, $dataRoot . DIRECTORY_SEPARATOR . 'users', $dataRoot . DIRECTORY_SEPARATOR . 'backups'] as $directory) {
    if (!is_dir($directory) && !mkdir($directory, 0700, true) && !is_dir($directory)) {
        http_response_code(500);
        exit('No se pudo crear la carpeta privada de datos: ' . htmlspecialchars($directory, ENT_QUOTES, 'UTF-8'));
    }
}

$dbPath = $dataRoot . DIRECTORY_SEPARATOR . 'krasty.sqlite';
try {
    $db = new PDO('sqlite:' . $dbPath, null, null, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);
    $db->exec('PRAGMA foreign_keys = ON');
    $db->exec('PRAGMA journal_mode = WAL');
    $db->exec('CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT NOT NULL UNIQUE,
        password_hash TEXT NOT NULL,
        is_admin INTEGER NOT NULL DEFAULT 0,
        quota_bytes INTEGER NOT NULL,
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    )');
    $db->exec('CREATE TABLE IF NOT EXISTS files (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        original_name TEXT NOT NULL,
        stored_name TEXT NOT NULL UNIQUE,
        size_bytes INTEGER NOT NULL,
        mime_type TEXT NOT NULL,
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
    )');
    $db->exec('CREATE TABLE IF NOT EXISTS conversations (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        role TEXT NOT NULL CHECK(role IN (\'user\', \'assistant\')),
        content TEXT NOT NULL,
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
    )');
    $db->exec('CREATE TABLE IF NOT EXISTS audit_log (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        action TEXT NOT NULL,
        details TEXT NOT NULL DEFAULT \'\',
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    )');
} catch (Throwable $exception) {
    http_response_code(500);
    exit('No se pudo abrir la base de datos privada. Compruebe que la extensión sqlite3/PDO SQLite está activada en PHP.');
}

session_name('krasty_session');
session_set_cookie_params([
    'lifetime' => 0,
    'path' => (string)($config['base_path'] ?: '/'),
    'secure' => (bool)$config['cookie_secure'],
    'httponly' => true,
    'samesite' => 'Lax',
]);
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

function base_url(string $path = ''): string {
    global $config;
    $base = rtrim((string)($config['base_path'] ?? ''), '/');
    return $base . '/' . ltrim($path, '/');
}

function redirect_to(string $path): never {
    header('Location: ' . base_url($path), true, 303);
    exit;
}

function escape_html(string $value): string {
    return htmlspecialchars($value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function csrf_token(): string {
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return (string)$_SESSION['csrf'];
}

function require_csrf(): void {
    $provided = (string)($_POST['csrf'] ?? '');
    $expected = (string)($_SESSION['csrf'] ?? '');
    if ($provided === '' || $expected === '' || !hash_equals($expected, $provided)) {
        http_response_code(403);
        exit('La petición no es válida. Recargue la página e inténtelo de nuevo.');
    }
}

function current_user(): ?array {
    global $db;
    $id = (int)($_SESSION['user_id'] ?? 0);
    if ($id < 1) return null;
    $statement = $db->prepare('SELECT id, username, is_admin, quota_bytes, created_at FROM users WHERE id = ?');
    $statement->execute([$id]);
    return $statement->fetch() ?: null;
}

function require_login(): array {
    $user = current_user();
    if (!$user) redirect_to('login');
    return $user;
}

function require_admin(): array {
    $user = require_login();
    if ((int)$user['is_admin'] !== 1) {
        http_response_code(403);
        exit('Solo un administrador puede abrir esta página.');
    }
    return $user;
}

function is_valid_username(string $username): bool {
    return (bool)preg_match('/^[a-zA-Z0-9][a-zA-Z0-9_-]{2,31}$/', $username);
}

function user_folder(array $user): string {
    global $dataRoot;
    $folder = $dataRoot . DIRECTORY_SEPARATOR . 'users' . DIRECTORY_SEPARATOR . $user['id'] . '-' . $user['username'];
    $files = $folder . DIRECTORY_SEPARATOR . 'files';
    if (!is_dir($files) && !mkdir($files, 0700, true) && !is_dir($files)) {
        throw new RuntimeException('No se pudo preparar el almacenamiento del usuario.');
    }
    return $folder;
}

function used_bytes(int $userId): int {
    global $db;
    $statement = $db->prepare('SELECT COALESCE(SUM(size_bytes), 0) AS total FROM files WHERE user_id = ?');
    $statement->execute([$userId]);
    return (int)$statement->fetchColumn();
}

function log_action(?int $userId, string $action, string $details = ''): void {
    global $db;
    $statement = $db->prepare('INSERT INTO audit_log (user_id, action, details) VALUES (?, ?, ?)');
    $statement->execute([$userId, $action, substr($details, 0, 500)]);
}

function render_page(string $title, string $body, ?array $user = null): never {
    global $config;
    $name = escape_html((string)($config['app_name'] ?? 'Krasty Kebab'));
    $nav = $user
        ? '<a href="' . escape_html(base_url($user['username'] . '/Krasty/')) . '">Mi Krasty</a><a href="' . escape_html(base_url('logout')) . '">Salir</a>'
        : '<a href="' . escape_html(base_url('login')) . '">Entrar</a><a href="' . escape_html(base_url('register')) . '">Registro</a>';
    if ($user && (int)$user['is_admin'] === 1) $nav .= '<a href="' . escape_html(base_url('admin')) . '">Administración</a>';
    echo '<!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>' . escape_html($title) . ' · ' . $name . '</title><link rel="stylesheet" href="' . escape_html(base_url('assets/style.css')) . '"></head><body><header><div class="brand">🥙 ' . $name . '</div><nav>' . $nav . '</nav></header><main>' . $body . '</main><footer>Datos privados por usuario · Copia secundaria programada · Bóveda cifrada</footer></body></html>';
    exit;
}

function model_response(string $message): string {
    global $config;
    $model = $config['model'] ?? [];
    if (empty($model['enabled']) || ($model['provider'] ?? '') !== 'ollama') {
        return 'El chat de modelo local no está configurado todavía. Un administrador debe activar Ollama en config.php.';
    }
    if (!function_exists('curl_init')) {
        return 'La extensión cURL de PHP no está activa. Abra XAMPP, habilite curl en php.ini y reinicie Apache.';
    }
    $handle = curl_init((string)$model['ollama_url']);
    curl_setopt_array($handle, [
        CURLOPT_POST => true,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CONNECTTIMEOUT => 5,
        CURLOPT_TIMEOUT => max(10, (int)($model['timeout_seconds'] ?? 120)),
        CURLOPT_HTTPHEADER => ['Content-Type: application/json'],
        CURLOPT_POSTFIELDS => json_encode([
            'model' => (string)($model['default_model'] ?? 'llama3'),
            'prompt' => $message,
            'stream' => false,
        ], JSON_UNESCAPED_UNICODE),
    ]);
    $raw = curl_exec($handle);
    $http = (int)curl_getinfo($handle, CURLINFO_HTTP_CODE);
    $error = curl_error($handle);
    curl_close($handle);
    $decoded = is_string($raw) ? json_decode($raw, true) : null;
    if ($http >= 200 && $http < 300 && is_array($decoded) && !empty($decoded['response'])) return (string)$decoded['response'];
    return 'No se pudo obtener respuesta del modelo local. Compruebe que Ollama está iniciado y que el modelo indicado existe. ' . ($error ? 'Detalle: ' . $error : '');
}
