<?php
declare(strict_types=1);

/**
 * Crea un ZIP de usuarios y base de datos, y lo cifra por streaming con AES-256-CBC + HMAC-SHA-256.
 * El diseño por streaming evita cargar archivos grandes en memoria. El archivo resultante requiere
 * la contraseña de config.php y el script decrypt_vault_backup.php para recuperarse.
 */
if (PHP_SAPI !== 'cli') exit("Este script solo puede ejecutarse en la consola de Windows.\n");
if (!class_exists('ZipArchive') || !function_exists('openssl_encrypt')) exit("Faltan las extensiones PHP zip u openssl. Actívelas en php.ini y reinicie Apache.\n");
set_time_limit(0);

$configFile = dirname(__DIR__) . DIRECTORY_SEPARATOR . 'config' . DIRECTORY_SEPARATOR . 'config.php';
if (!is_file($configFile)) exit("Falta config.php.\n");
$config = require $configFile;
$dataRoot = rtrim((string)$config['data_root'], '/\\');
$passphrase = (string)($config['vault_passphrase'] ?? '');
if (strlen($passphrase) < 20 || str_contains($passphrase, 'REEMPLACE_')) exit("Configure una vault_passphrase larga antes de crear la bóveda.\n");

$usersDirectory = $dataRoot . DIRECTORY_SEPARATOR . 'users';
$sourceDatabase = $dataRoot . DIRECTORY_SEPARATOR . 'krasty.sqlite';
$vaultDirectory = $dataRoot . DIRECTORY_SEPARATOR . 'backups' . DIRECTORY_SEPARATOR . 'vault';
if (!is_dir($usersDirectory) || !is_file($sourceDatabase)) exit("No se encontraron los datos de Krasty.\n");
if (!is_dir($vaultDirectory) && !mkdir($vaultDirectory, 0700, true) && !is_dir($vaultDirectory)) exit("No se pudo crear la carpeta de bóveda.\n");

function create_consistent_vault_database(string $source, string $target): void {
    $temporary = $target . '.tmp';
    @unlink($temporary);
    $read = new SQLite3($source, SQLITE3_OPEN_READONLY);
    $write = new SQLite3($temporary, SQLITE3_OPEN_READWRITE | SQLITE3_OPEN_CREATE);
    if (!method_exists($read, 'backup') || !$read->backup($write)) {
        throw new RuntimeException('No fue posible crear un snapshot SQLite consistente.');
    }
    $write->close();
    $read->close();
    if (!rename($temporary, $target)) throw new RuntimeException('No se pudo finalizar el snapshot de bóveda.');
}

function add_tree_to_zip(ZipArchive $zip, string $sourceDirectory, string $archivePrefix): void {
    $iterator = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($sourceDirectory, FilesystemIterator::SKIP_DOTS), RecursiveIteratorIterator::LEAVES_ONLY);
    foreach ($iterator as $entry) {
        if (!$entry->isFile() || $entry->isLink()) continue;
        $path = $entry->getPathname();
        $relative = substr($path, strlen($sourceDirectory) + 1);
        $destination = $archivePrefix . '/' . str_replace('\\', '/', $relative);
        if (!$zip->addFile($path, $destination)) throw new RuntimeException('No se pudo añadir a ZIP: ' . $relative);
    }
}

function encrypt_stream(string $input, string $output, string $passphrase): array {
    $magic = 'KRASTYVAULT1';
    $salt = random_bytes(16);
    $iv = random_bytes(16);
    $material = hash_pbkdf2('sha256', $passphrase, $salt, 250000, 64, true);
    $encryptionKey = substr($material, 0, 32);
    $macKey = substr($material, 32, 32);
    $inputHandle = fopen($input, 'rb');
    $outputHandle = fopen($output, 'wb');
    if (!$inputHandle || !$outputHandle) throw new RuntimeException('No se pudo abrir el archivo temporal de bóveda.');
    $header = $magic . $salt . $iv;
    fwrite($outputHandle, $header);
    $hmac = hash_init('sha256', HASH_HMAC, $macKey);
    hash_update($hmac, $header);
    $chunkBytes = 1024 * 1024; // Siempre divisible por 16.
    $pending = '';
    try {
        while (!feof($inputHandle)) {
            $piece = fread($inputHandle, $chunkBytes);
            if ($piece === false) throw new RuntimeException('No se pudo leer el ZIP temporal.');
            if ($piece === '') break;
            $pending .= $piece;
            // Conserva al menos el último bloque completo para añadir PKCS#7 al finalizar.
            $processable = strlen($pending) - 16;
            $processable -= $processable % 16;
            if ($processable > 0) {
                $toEncrypt = substr($pending, 0, $processable);
                $pending = substr($pending, $processable);
                $cipher = openssl_encrypt($toEncrypt, 'aes-256-cbc', $encryptionKey, OPENSSL_RAW_DATA | OPENSSL_ZERO_PADDING, $iv);
                if ($cipher === false) throw new RuntimeException('OpenSSL no pudo cifrar el archivo.');
                $iv = substr($cipher, -16);
                fwrite($outputHandle, $cipher);
                hash_update($hmac, $cipher);
            }
        }
        $padding = 16 - (strlen($pending) % 16);
        if ($padding === 0) $padding = 16;
        $pending .= str_repeat(chr($padding), $padding);
        $cipher = openssl_encrypt($pending, 'aes-256-cbc', $encryptionKey, OPENSSL_RAW_DATA | OPENSSL_ZERO_PADDING, $iv);
        if ($cipher === false) throw new RuntimeException('OpenSSL no pudo terminar el cifrado.');
        fwrite($outputHandle, $cipher);
        hash_update($hmac, $cipher);
        $tag = hash_final($hmac, true);
        fwrite($outputHandle, $tag);
    } finally {
        fclose($inputHandle);
        fclose($outputHandle);
    }
    return ['salt' => bin2hex($salt), 'iv' => bin2hex(substr($header, -16)), 'hmac_sha256' => bin2hex($tag)];
}

$stamp = gmdate('Y-m-d_H-i-s');
$snapshotDirectory = $dataRoot . DIRECTORY_SEPARATOR . 'backups' . DIRECTORY_SEPARATOR . 'vault_stage';
$databaseSnapshot = $snapshotDirectory . DIRECTORY_SEPARATOR . 'krasty.sqlite';
$temporaryZip = $vaultDirectory . DIRECTORY_SEPARATOR . 'krasty-vault-' . $stamp . '.zip.tmp';
$encrypted = $vaultDirectory . DIRECTORY_SEPARATOR . 'krasty-vault-' . $stamp . '.zip.enc';

try {
    if (!is_dir($snapshotDirectory) && !mkdir($snapshotDirectory, 0700, true) && !is_dir($snapshotDirectory)) throw new RuntimeException('No se pudo crear la carpeta temporal de bóveda.');
    create_consistent_vault_database($sourceDatabase, $databaseSnapshot);
    $zip = new ZipArchive();
    if ($zip->open($temporaryZip, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) throw new RuntimeException('No se pudo crear el ZIP temporal.');
    add_tree_to_zip($zip, $usersDirectory, 'users');
    if (!$zip->addFile($databaseSnapshot, 'database/krasty.sqlite')) throw new RuntimeException('No se pudo añadir el snapshot de base de datos.');
    $zip->setArchiveComment('Krasty Kebab vault: ' . gmdate('c'));
    if (!$zip->close()) throw new RuntimeException('No se pudo cerrar el ZIP temporal.');
    $metadata = encrypt_stream($temporaryZip, $encrypted, $passphrase);
    @unlink($temporaryZip);
    @unlink($databaseSnapshot);
    $manifest = [
        'format' => 'KRASTYVAULT1',
        'created_at' => gmdate('c'),
        'encrypted_file' => basename($encrypted),
        'sha256' => hash_file('sha256', $encrypted),
        'encryption' => 'AES-256-CBC + HMAC-SHA-256; PBKDF2-SHA256 (250000 iterations)',
        'metadata' => $metadata,
        'recovery_script' => 'decrypt_vault_backup.php',
    ];
    file_put_contents($encrypted . '.manifest.json', json_encode($manifest, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES), LOCK_EX);
    file_put_contents($encrypted . '.sha256', $manifest['sha256'] . '  ' . basename($encrypted) . PHP_EOL, LOCK_EX);
    echo "Bóveda creada: {$encrypted}" . PHP_EOL;
    echo "SHA-256: {$manifest['sha256']}" . PHP_EOL;
    echo "Compruebe que dispone de espacio libre suficiente antes de crear bóvedas grandes y suba los tres archivos .enc, .manifest.json y .sha256 al almacenamiento externo.\n";
} catch (Throwable $exception) {
    @unlink($temporaryZip);
    @unlink($encrypted);
    fwrite(STDERR, "La bóveda no se creó: " . $exception->getMessage() . PHP_EOL);
    exit(1);
}
