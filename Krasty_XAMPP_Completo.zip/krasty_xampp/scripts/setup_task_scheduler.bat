@echo off
setlocal EnableExtensions

REM Ejecute este archivo con clic derecho > "Ejecutar como administrador".
REM Cree antes la cuenta local krastybackup en ambos ordenadores con la misma contraseña.
REM Consulte MANUAL_COMPLETO.md antes de continuar.
set "PROJECT_DIR=C:\KrastyApp"
set "TASK_NAME=Krasty Kebab - Copia al segundo ordenador"
set "TASK_COMMAND=cmd.exe /c \"%PROJECT_DIR%\scripts\backup_to_second_pc.bat\""

net session >nul 2>&1
if not "%errorlevel%"=="0" (
  echo.
  echo Debe ejecutar este archivo como administrador.
  echo Clic derecho sobre setup_task_scheduler.bat y elija "Ejecutar como administrador".
  pause
  exit /b 1
)

if not exist "%PROJECT_DIR%\scripts\backup_to_second_pc.bat" (
  echo No se encontro el script de copia en %PROJECT_DIR%.
  echo Edite PROJECT_DIR en este archivo y pruebe de nuevo.
  pause
  exit /b 2
)

set /p "TASK_USER=Escriba la cuenta de copia [.%COMPUTERNAME%\krastybackup]: "
if "%TASK_USER%"=="" set "TASK_USER=%COMPUTERNAME%\krastybackup"

echo.
echo Se pedira la contraseña de la cuenta de copia. No se mostrara en pantalla.
echo La tarea se ejecutara cada 30 minutos aunque no haya sesion abierta.
schtasks /Create /TN "%TASK_NAME%" /TR "%TASK_COMMAND%" /SC MINUTE /MO 30 /RU "%TASK_USER%" /RP * /RL HIGHEST /F
if errorlevel 1 (
  echo No se pudo crear la tarea. Revise la cuenta indicada y pruebe de nuevo.
  pause
  exit /b 3
)

echo.
echo Tarea creada: %TASK_NAME%
echo Pruebe ahora: schtasks /Run /TN "%TASK_NAME%"
echo Revise el registro: %PROJECT_DIR%\logs\backup_to_second_pc.log
pause
