@echo off
setlocal EnableExtensions EnableDelayedExpansion

REM Krasty Kebab XAMPP - Copia automática al segundo ordenador.
REM Edite solo estas tres rutas antes de usarlo.
set "PHP_EXE=C:\xampp\php\php.exe"
set "PROJECT_DIR=C:\KrastyApp"
set "BACKUP_SHARE=\\ORDENADOR-RESPALDO\KrastyBackups"

set "LOG_DIR=%PROJECT_DIR%\logs"
set "DATA_ROOT=C:\KrastyData"
set "STAGE_DIR=%DATA_ROOT%\backups\secondary_stage"
set "LOG_FILE=%LOG_DIR%\backup_to_second_pc.log"
set "LOCK_FILE=%LOG_DIR%\backup_to_second_pc.lock"
set "EXIT_CODE=0"

if not exist "%LOG_DIR%" mkdir "%LOG_DIR%"
if exist "%LOCK_FILE%" (
  echo [%date% %time%] AVISO: se omitio una copia porque la anterior sigue en curso. >> "%LOG_FILE%"
  exit /b 0
)
echo %date% %time% > "%LOCK_FILE%"
echo [%date% %time%] Inicio de respaldo >> "%LOG_FILE%"

if not exist "%PHP_EXE%" (
  echo ERROR: No se encontro PHP en %PHP_EXE% >> "%LOG_FILE%"
  set "EXIT_CODE=10"
  goto :finish
)
if not exist "%BACKUP_SHARE%\NUL" (
  echo ERROR: No se puede abrir el recurso compartido %BACKUP_SHARE% >> "%LOG_FILE%"
  set "EXIT_CODE=11"
  goto :finish
)

REM 1. Crea una copia consistente de SQLite en una carpeta temporal privada.
"%PHP_EXE%" "%PROJECT_DIR%\scripts\backup_snapshot.php" >> "%LOG_FILE%" 2>&1
if errorlevel 1 (
  echo ERROR: El snapshot de SQLite fallo. >> "%LOG_FILE%"
  set "EXIT_CODE=12"
  goto :finish
)

REM 2. Replica usuarios y snapshot. No se usa /MIR ni /PURGE para no borrar una versión
REM que pudiera ser útil en el segundo PC durante una recuperación.
robocopy "%DATA_ROOT%\users" "%BACKUP_SHARE%\users" /E /Z /R:2 /W:5 /COPY:DAT /DCOPY:DAT /FFT /XJ /NFL /NDL /NP >> "%LOG_FILE%"
set "RC_FILES=!ERRORLEVEL!"
robocopy "%STAGE_DIR%" "%BACKUP_SHARE%\database" /E /Z /R:2 /W:5 /COPY:DAT /DCOPY:DAT /FFT /XJ /NFL /NDL /NP >> "%LOG_FILE%"
set "RC_DATABASE=!ERRORLEVEL!"

REM Robocopy utiliza códigos 0 a 7 para éxito o avisos. 8 o más significa fallo.
if !RC_FILES! GEQ 8 (
  echo ERROR: Robocopy de archivos devolvio !RC_FILES!. >> "%LOG_FILE%"
  set "EXIT_CODE=!RC_FILES!"
  goto :finish
)
if !RC_DATABASE! GEQ 8 (
  echo ERROR: Robocopy de base de datos devolvio !RC_DATABASE!. >> "%LOG_FILE%"
  set "EXIT_CODE=!RC_DATABASE!"
  goto :finish
)

echo [%date% %time%] Respaldo finalizado. Archivos=!RC_FILES! Base=!RC_DATABASE! >> "%LOG_FILE%"

:finish
if exist "%LOCK_FILE%" del /q "%LOCK_FILE%" >nul 2>&1
exit /b %EXIT_CODE%
