<?php
declare(strict_types=1);

/**
 * Uso: php decrypt_vault_backup.php "C:\ruta\krasty-vault-...zip.enc" "C:\KrastyRecuperado"
 * La contraseña se lee de config/config.php. No se extrae nada hasta verificar el HMAC interno.
 */
if (PHP_SAPI !== 'cli') exit("Este script solo puede ejecutarse en la consola de Windows.\n");
if (!class_exists('ZipArchive') || !function_exists('openssl_decrypt')) exit("Faltan las extensiones PHP zip u openssl.\n");
set_time_limit(0);

$input = $argv[1] ?? '';
$destination = $argv[2] ?? '';
if ($input === '' || $destination === '') exit("Uso: php decrypt_vault_backup.php \"C:\\ruta\\archivo.zip.enc\" \"C:\\KrastyRecuperado\"\n");
if (!is_file($input)) exit("No se encontró la bóveda indicada.\n");
$configFile = dirname(__DIR__) . DIRECTORY_SEPARATOR . 'config' . DIRECTORY_SEPARATOR . 'config.php';
if (!is_file($configFile)) exit("Falta config.php.\n");
$config = require $configFile;
$passphrase = (string)($config['vault_passphrase'] ?? '');
if (strlen($passphrase) < 20 || str_contains($passphrase, 'REEMPLACE_')) exit("La vault_passphrase no está configurada.\n");

function decrypt_vault_stream(string $input, string $temporaryZip, string $passphrase): void {
    $magic = 'KRASTYVAULT1';
    $headerLength = strlen($magic) + 16 + 16;
    $fileSize = filesize($input);
    if ($fileSize === false || $fileSize <= $headerLength + 32) throw new RuntimeException('El archivo de bóveda es demasiado pequeño o está dañado.');
    $inputHandle = fopen($input, 'rb');
    if (!$inputHandle) throw new RuntimeException('No se pudo leer la bóveda.');
    $header = fread($inputHandle, $headerLength);
    if (strlen($header) !== $headerLength || substr($header, 0, strlen($magic)) !== $magic) throw new RuntimeException('El formato de bóveda no es válido.');
    $salt = substr($header, strlen($magic), 16);
    $iv = substr($header, strlen($magic) + 16, 16);
    $material = hash_pbkdf2('sha256', $passphrase, $salt, 250000, 64, true);
    $encryptionKey = substr($material, 0, 32);
    $macKey = substr($material, 32, 32);
    $cipherBytes = $fileSize - $headerLength - 32;
    if ($cipherBytes < 16 || $cipherBytes % 16 !== 0) throw new RuntimeException('El tamaño cifrado no es válido.');
    fseek($inputHandle, $fileSize - 32);
    $storedTag = fread($inputHandle, 32);
    fseek($inputHandle, $headerLength);

    $outputHandle = fopen($temporaryZip, 'wb');
    if (!$outputHandle) throw new RuntimeException('No se pudo crear el ZIP temporal.');
    $hmac = hash_init('sha256', HASH_HMAC, $macKey);
    hash_update($hmac, $header);
    $remaining = $cipherBytes;
    $pendingPlaintext = null;
    try {
        while ($remaining > 0) {
            $take = min(1024 * 1024, $remaining);
            $ciphertext = fread($inputHandle, $take);
            if ($ciphertext === false || strlen($ciphertext) !== $take) throw new RuntimeException('La bóveda termina antes de tiempo.');
            hash_update($hmac, $ciphertext);
            $plain = openssl_decrypt($ciphertext, 'aes-256-cbc', $encryptionKey, OPENSSL_RAW_DATA | OPENSSL_ZERO_PADDING, $iv);
            if ($plain === false) throw new RuntimeException('No se pudo descifrar la bóveda.');
            $iv = substr($ciphertext, -16);
            if ($pendingPlaintext !== null) fwrite($outputHandle, $pendingPlaintext);
            $pendingPlaintext = $plain;
            $remaining -= $take;
        }
        $actualTag = hash_final($hmac, true);
        if (!hash_equals($storedTag, $actualTag)) throw new RuntimeException('La contraseña es incorrecta o el archivo fue alterado. No se restauró nada.');
        if ($pendingPlaintext === null || $pendingPlaintext === '') throw new RuntimeException('La bóveda no contiene datos cifrados válidos.');
        $padding = ord(substr($pendingPlaintext, -1));
        if ($padding < 1 || $padding > 16 || substr($pendingPlaintext, -$padding) !== str_repeat(chr($padding), $padding)) throw new RuntimeException('El relleno cifrado es inválido.');
        fwrite($outputHandle, substr($pendingPlaintext, 0, -$padding));
    } finally {
        fclose($inputHandle);
        fclose($outputHandle);
    }
}

function zip_entries_are_safe(ZipArchive $zip): bool {
    for ($index = 0; $index < $zip->numFiles; $index++) {
        $name = (string)$zip->getNameIndex($index);
        if ($name === '' || str_starts_with($name, '/') || str_contains($name, '../') || str_contains($name, '..\\') || preg_match('/^[a-zA-Z]:/', $name)) return false;
    }
    return true;
}

$destination = rtrim($destination, '/\\');
if (is_dir($destination) && (scandir($destination) ?: []) !== ['.', '..']) exit("La carpeta de destino debe estar vacía para no mezclar archivos existentes.\n");
if (!is_dir($destination) && !mkdir($destination, 0700, true) && !is_dir($destination)) exit("No se pudo crear el destino de recuperación.\n");
$temporaryZip = $destination . DIRECTORY_SEPARATOR . 'krasty-recovery-temporary.zip';
@unlink($temporaryZip);
try {
    decrypt_vault_stream($input, $temporaryZip, $passphrase);
    $zip = new ZipArchive();
    if ($zip->open($temporaryZip) !== true) throw new RuntimeException('El contenido descifrado no es un ZIP válido.');
    if (!zip_entries_are_safe($zip)) { $zip->close(); throw new RuntimeException('El ZIP contiene rutas no seguras y no se extraerá.'); }
    if (!$zip->extractTo($destination)) { $zip->close(); throw new RuntimeException('No se pudieron extraer los archivos de recuperación.'); }
    $zip->close();
    @unlink($temporaryZip);
    echo "Bóveda verificada y extraída en: {$destination}" . PHP_EOL;
    echo "Revise users/ y database/krasty.sqlite antes de reemplazar datos en producción.\n";
} catch (Throwable $exception) {
    @unlink($temporaryZip);
    fwrite(STDERR, "La recuperación falló: " . $exception->getMessage() . PHP_EOL);
    exit(1);
}
