<?php
declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    http_response_code(403);
    exit("Este script solo puede ejecutarse desde la consola de Windows.\n");
}

$configFile = dirname(__DIR__) . DIRECTORY_SEPARATOR . 'config' . DIRECTORY_SEPARATOR . 'config.php';
if (!is_file($configFile)) exit("Falta config.php.\n");
$config = require $configFile;
$dataRoot = rtrim((string)$config['data_root'], '/\\');
$sourcePath = $dataRoot . DIRECTORY_SEPARATOR . 'krasty.sqlite';
$backupDirectory = $dataRoot . DIRECTORY_SEPARATOR . 'backups' . DIRECTORY_SEPARATOR . 'secondary_stage';
$targetPath = $backupDirectory . DIRECTORY_SEPARATOR . 'krasty.sqlite';

if (!is_file($sourcePath)) exit("No existe la base de datos todavía. Inicie la aplicación y registre una cuenta primero.\n");
if (!is_dir($backupDirectory) && !mkdir($backupDirectory, 0700, true) && !is_dir($backupDirectory)) exit("No se pudo crear el directorio temporal de respaldo.\n");

$temporary = $targetPath . '.tmp';
@unlink($temporary);
try {
    $source = new SQLite3($sourcePath, SQLITE3_OPEN_READONLY);
    $destination = new SQLite3($temporary, SQLITE3_OPEN_READWRITE | SQLITE3_OPEN_CREATE);
    if (!method_exists($source, 'backup')) {
        throw new RuntimeException('La extensión SQLite3 de esta versión de PHP no ofrece SQLite3::backup(). Actualice XAMPP/PHP antes de programar copias.');
    }
    if (!$source->backup($destination)) {
        throw new RuntimeException('SQLite no pudo crear una copia consistente.');
    }
    $destination->close();
    $source->close();
    if (!rename($temporary, $targetPath)) throw new RuntimeException('No se pudo finalizar la copia de base de datos.');

    $manifest = [
        'created_at' => gmdate('c'),
        'database_file' => 'krasty.sqlite',
        'database_sha256' => hash_file('sha256', $targetPath),
        'users_directory' => $dataRoot . DIRECTORY_SEPARATOR . 'users',
    ];
    file_put_contents($backupDirectory . DIRECTORY_SEPARATOR . 'manifest.json', json_encode($manifest, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES), LOCK_EX);
    echo "Snapshot consistente creado en: {$targetPath}" . PHP_EOL;
} catch (Throwable $exception) {
    @unlink($temporary);
    fwrite(STDERR, "El snapshot falló: " . $exception->getMessage() . PHP_EOL);
    exit(1);
}
