# 🥙 Krasty Kebab - Manual de Producción y Despliegue

Este proyecto es la versión definitiva y unificada de **Garras**, optimizada para funcionar en **hostings compartidos** y entornos de producción.

## 🌟 Características de Producción

1.  **Integración de Chutes.ai**: Soporte nativo para la API de Chutes.ai con descubrimiento dinámico de modelos.
2.  **Memoria Colectiva**: Sistema de multi-agentes que comparten conocimientos y configuraciones.
3.  **Avatar Realtime**: Ventana de visualización responsiva (Iframe) para avatares y proyectos externos.
4.  **Optimizado para Hosting**: Utiliza SQLite para evitar la necesidad de bases de datos externas y es compatible con la mayoría de los servicios de hosting Node.js.

## 🚀 Guía de Despliegue en Hosting Compartido

### 1. Preparación de Archivos
- Sube el contenido de la carpeta `krasty_kebab` a tu servidor (vía FTP o Git).
- Asegúrate de que la carpeta `db/` tenga permisos de escritura (755 o 777) para que SQLite pueda crear la base de datos.

### 2. Configuración de Node.js
- En tu panel de hosting (cPanel, Plesk, etc.), crea una nueva aplicación Node.js.
- Establece el **Application Startup File** como `index.js`.
- Instala las dependencias ejecutando `npm install` desde la terminal del hosting.

### 3. Variables de Entorno (Opcional)
Puedes configurar estas variables en tu panel de hosting para mayor seguridad:
- `PORT`: El puerto en el que correrá la app (por defecto 3000).
- `SECRET_KEY`: Una cadena aleatoria para firmar los tokens de sesión.

## 🛠️ Uso de Chutes.ai

1.  Ve a la pestaña de **Configuración (⚙️)**.
2.  Introduce tu **API Key de Chutes.ai**.
3.  Guarda la configuración.
4.  En el selector de proveedores, elige **Chutes.ai** y verás cómo se cargan automáticamente todos los modelos disponibles en su plataforma.

## 🎤 Soporte de Voz y Avatar

- Usa el botón de micrófono para dictar tus órdenes.
- Activa el visor de cámara (📹) para ver al agente en tiempo real.
- Puedes cargar cualquier URL externa como avatar en la configuración de cada agente.

---
*¡Tu central de inteligencia artificial, lista para el mundo real!*
