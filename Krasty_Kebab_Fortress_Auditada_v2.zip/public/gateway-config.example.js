// Copie este archivo como gateway-config.js y sustituya las direcciones de ejemplo.
// No incluya secretos ni claves API en este archivo: será visible desde el navegador.
window.KRASTY_GATEWAY_CONFIG = {
  // Debe ser una URL HTTPS accesible solo mediante VPN o túnel autenticado, si se expone desde Internet.
  localUrl: 'https://krasty-local.ejemplo.com',
  // Nodo de contingencia; debe configurarse con NODE_ROLE=standby hasta una promoción controlada.
  cloudUrl: 'https://krasty-respaldo.ejemplo.com',
  // Portal HTTPS de la bóveda. La recuperación de datos cifrados requiere la clave local, que nunca debe subirse.
  vaultUrl: 'https://archivos.ejemplo.com/krasty-vault/'
};
