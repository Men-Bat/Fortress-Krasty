require('dotenv').config({ path: require('path').join(__dirname, '..', '.env') });

const axios = require('axios');

const url = process.argv[2] || process.env.HEALTHCHECK_URL || `http://127.0.0.1:${process.env.PORT || 3000}`;

async function main() {
  const response = await axios.get(`${url.replace(/\/$/, '')}/api/health`, { timeout: 5000, validateStatus: () => true });
  if (response.status !== 200 || response.data?.status !== 'ok') {
    throw new Error(`Nodo no saludable: HTTP ${response.status}.`);
  }
  console.log(JSON.stringify(response.data, null, 2));
}

main().catch((error) => {
  console.error(error.message);
  process.exit(1);
});
