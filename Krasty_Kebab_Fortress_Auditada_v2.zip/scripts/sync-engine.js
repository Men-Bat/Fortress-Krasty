require('dotenv').config({ path: require('path').join(__dirname, '..', '.env') });

const { execFile } = require('child_process');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const util = require('util');
const axios = require('axios');
const sqlite3 = require('sqlite3').verbose();

const execFileAsync = util.promisify(execFile);
const rootDir = path.join(__dirname, '..');
const dbPath = path.join(rootDir, 'db', 'krasty.db');
const archiveDir = path.resolve(rootDir, process.env.ARCHIVE_DIR || 'archives');
const outgoingDir = path.join(archiveDir, 'outgoing');
const cloudNodeUrl = String(process.env.CLOUD_NODE_URL || '').replace(/\/$/, '');
const syncToken = process.env.SYNC_TOKEN;
const intervalMinutes = Number(process.env.SYNC_INTERVAL_MINUTES || 30);
let running = false;

function requireConfig() {
  if (!syncToken || syncToken.length < 32) throw new Error('SYNC_TOKEN no está configurado correctamente.');
  if (!cloudNodeUrl || !/^https:\/\//i.test(cloudNodeUrl)) throw new Error('CLOUD_NODE_URL debe ser una URL HTTPS válida.');
  fs.mkdirSync(outgoingDir, { recursive: true, mode: 0o700 });
}

function createConsistentDatabaseSnapshot(target) {
  return new Promise((resolve, reject) => {
    const source = new sqlite3.Database(dbPath, sqlite3.OPEN_READONLY, (openError) => {
      if (openError) return reject(openError);
      source.backup(target, (backupError) => {
        source.close();
        if (backupError) return reject(backupError);
        resolve();
      });
    });
  });
}

async function uploadDatabaseSnapshot() {
  const stamp = new Date().toISOString().replace(/[:.]/g, '-');
  const snapshotPath = path.join(outgoingDir, `database-${stamp}.db`);
  await createConsistentDatabaseSnapshot(snapshotPath);
  const body = fs.readFileSync(snapshotPath);
  const sha256 = crypto.createHash('sha256').update(body).digest('hex');
  try {
    const response = await axios.post(`${cloudNodeUrl}/api/sync/upload`, {
      snapshotBase64: body.toString('base64'),
      sha256,
      createdAt: new Date().toISOString(),
      sourceNode: process.env.NODE_TYPE || 'local',
    }, { headers: { 'X-Sync-Token': syncToken }, timeout: 120000, maxBodyLength: 60 * 1024 * 1024 });
    console.log(`[cloud] ${response.status}: ${response.data.message}`);
  } finally {
    fs.unlinkSync(snapshotPath);
  }
}

async function createAndUploadVaultArchive() {
  const vaultUrl = String(process.env.VAULT_WEBDAV_URL || '').replace(/\/$/, '');
  if (!vaultUrl) {
    console.warn('[vault] Sin VAULT_WEBDAV_URL; se conserva únicamente la copia cifrada local.');
    return;
  }
  if (!/^https:\/\//i.test(vaultUrl)) throw new Error('VAULT_WEBDAV_URL debe usar HTTPS.');
  const { stdout } = await execFileAsync(process.execPath, [path.join(__dirname, 'create-snapshot.js')], { cwd: rootDir });
  const result = JSON.parse(stdout);
  const filePath = result.encryptedPath;
  const fileName = path.basename(filePath);
  const username = process.env.VAULT_WEBDAV_USERNAME;
  const password = process.env.VAULT_WEBDAV_PASSWORD;
  if (!username || !password) throw new Error('Faltan las credenciales de WebDAV para la bóveda.');
  const response = await axios.put(`${vaultUrl}/${encodeURIComponent(fileName)}`, fs.createReadStream(filePath), {
    headers: { 'Content-Type': 'application/octet-stream', 'X-Content-SHA256': result.sha256 },
    auth: { username, password },
    maxBodyLength: Infinity,
    maxContentLength: Infinity,
    timeout: 15 * 60 * 1000,
  });
  if (response.status < 200 || response.status >= 300) throw new Error(`La bóveda devolvió HTTP ${response.status}.`);
  console.log(`[vault] Archivo cifrado enviado: ${fileName}`);
}

async function runSync() {
  if (running) return console.warn('[sync] Omitido: una sincronización anterior continúa en curso.');
  if ((process.env.NODE_ROLE || 'primary') !== 'primary') return console.warn('[sync] El nodo no es primario; no se emiten respaldos.');
  running = true;
  try {
    await uploadDatabaseSnapshot();
    await createAndUploadVaultArchive();
  } catch (error) {
    console.error(`[sync] Fallo: ${error.message}`);
  } finally {
    running = false;
  }
}

try {
  requireConfig();
  runSync();
  setInterval(runSync, Math.max(5, intervalMinutes) * 60 * 1000);
} catch (error) {
  console.error(`[sync] Configuración inválida: ${error.message}`);
  process.exit(1);
}
