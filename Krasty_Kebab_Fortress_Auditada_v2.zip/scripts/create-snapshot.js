require('dotenv').config({ path: require('path').join(__dirname, '..', '.env') });

const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const archiver = require('archiver');

const rootDir = path.join(__dirname, '..');
const dbPath = path.join(rootDir, 'db', 'krasty.db');
const dataDir = path.resolve(rootDir, process.env.DATA_DIR || 'data');
const archiveDir = path.resolve(rootDir, process.env.ARCHIVE_DIR || 'archives');
const snapshotDir = path.join(archiveDir, 'snapshots');

function encryptionKey() {
  const encoded = process.env.VAULT_ENCRYPTION_KEY;
  if (!encoded) throw new Error('Falta VAULT_ENCRYPTION_KEY. Debe ser una clave Base64 de 32 bytes.');
  const key = Buffer.from(encoded, 'base64');
  if (key.length !== 32) throw new Error('VAULT_ENCRYPTION_KEY debe decodificar exactamente a 32 bytes.');
  return key;
}

function retentionDays() {
  const parsed = Number(process.env.SNAPSHOT_RETENTION_DAYS || 30);
  return Number.isInteger(parsed) && parsed > 0 ? parsed : 30;
}

function removeExpiredSnapshots() {
  const cutoff = Date.now() - retentionDays() * 24 * 60 * 60 * 1000;
  for (const file of fs.readdirSync(snapshotDir)) {
    const fullPath = path.join(snapshotDir, file);
    const info = fs.statSync(fullPath);
    if (info.isFile() && info.mtimeMs < cutoff) fs.unlinkSync(fullPath);
  }
}

function createZip(zipPath) {
  return new Promise((resolve, reject) => {
    const output = fs.createWriteStream(zipPath, { mode: 0o600 });
    const archive = archiver('zip', { zlib: { level: 9 } });
    output.on('close', resolve);
    archive.on('error', reject);
    archive.pipe(output);
    if (fs.existsSync(dbPath)) archive.file(dbPath, { name: 'database/krasty.db' });
    if (fs.existsSync(dataDir)) archive.directory(dataDir, 'user-files');
    archive.append(JSON.stringify({ createdAt: new Date().toISOString(), schema: 1 }, null, 2), { name: 'manifest.json' });
    archive.finalize();
  });
}

function encryptFile(inputPath, outputPath, key) {
  return new Promise((resolve, reject) => {
    const iv = crypto.randomBytes(12);
    const cipher = crypto.createCipheriv('aes-256-gcm', key, iv);
    const input = fs.createReadStream(inputPath);
    const output = fs.createWriteStream(outputPath, { mode: 0o600 });
    output.write(Buffer.concat([Buffer.from('KKF1'), iv]));
    input.pipe(cipher).pipe(output, { end: false });
    cipher.on('end', () => {
      try {
        output.write(cipher.getAuthTag());
        output.end();
      } catch (error) { reject(error); }
    });
    output.on('finish', resolve);
    input.on('error', reject);
    output.on('error', reject);
    cipher.on('error', reject);
  });
}

async function main() {
  if (!fs.existsSync(dbPath)) throw new Error('No existe la base de datos; inicie la aplicación una vez antes de crear un snapshot.');
  fs.mkdirSync(snapshotDir, { recursive: true, mode: 0o700 });
  const stamp = new Date().toISOString().replace(/[:.]/g, '-');
  const zipPath = path.join(snapshotDir, `krasty-${stamp}.zip`);
  const encryptedPath = `${zipPath}.enc`;
  await createZip(zipPath);
  await encryptFile(zipPath, encryptedPath, encryptionKey());
  fs.unlinkSync(zipPath);
  const hash = crypto.createHash('sha256').update(fs.readFileSync(encryptedPath)).digest('hex');
  fs.writeFileSync(`${encryptedPath}.sha256`, `${hash}  ${path.basename(encryptedPath)}\n`, { mode: 0o600 });
  removeExpiredSnapshots();
  console.log(JSON.stringify({ encryptedPath, sha256: hash }, null, 2));
}

main().catch((error) => { console.error(error.message); process.exit(1); });
