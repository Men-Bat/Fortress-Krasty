require('dotenv').config({ path: require('path').join(__dirname, '..', '.env') });

const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const { pipeline } = require('stream/promises');

const inputPath = process.argv[2];
const outputPath = process.argv[3];

function keyFromEnvironment() {
  const value = process.env.VAULT_ENCRYPTION_KEY;
  if (!value) throw new Error('Falta VAULT_ENCRYPTION_KEY.');
  const key = Buffer.from(value, 'base64');
  if (key.length !== 32) throw new Error('VAULT_ENCRYPTION_KEY debe decodificar exactamente a 32 bytes.');
  return key;
}

async function main() {
  if (!inputPath || !outputPath) throw new Error('Uso: node scripts/decrypt-snapshot.js <archivo.enc> <salida.zip>');
  const stat = fs.statSync(inputPath);
  if (stat.size < 33) throw new Error('El archivo cifrado es demasiado pequeño o no tiene un formato válido.');
  const descriptor = fs.openSync(inputPath, 'r');
  const header = Buffer.alloc(16);
  const tag = Buffer.alloc(16);
  fs.readSync(descriptor, header, 0, 16, 0);
  fs.readSync(descriptor, tag, 0, 16, stat.size - 16);
  fs.closeSync(descriptor);
  if (header.subarray(0, 4).toString() !== 'KKF1') throw new Error('Cabecera no reconocida. No es un archivo Fortress válido.');
  const decipher = crypto.createDecipheriv('aes-256-gcm', keyFromEnvironment(), header.subarray(4));
  decipher.setAuthTag(tag);
  await pipeline(
    fs.createReadStream(inputPath, { start: 16, end: stat.size - 17 }),
    decipher,
    fs.createWriteStream(outputPath, { mode: 0o600 })
  );
  console.log(`Archivo recuperado: ${outputPath}`);
}

main().catch((error) => {
  console.error(`Recuperación fallida: ${error.message}`);
  process.exit(1);
});
