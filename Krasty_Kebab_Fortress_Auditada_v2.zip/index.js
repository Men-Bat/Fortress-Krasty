require('dotenv').config();

const crypto = require('crypto');
const express = require('express');
const rateLimit = require('express-rate-limit');
const helmet = require('helmet');
const sqlite3 = require('sqlite3').verbose();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const path = require('path');
const axios = require('axios');
const cookieParser = require('cookie-parser');
const fs = require('fs');

const app = express();
const rootDir = __dirname;
const dataDir = path.resolve(rootDir, process.env.DATA_DIR || 'data');
const archiveDir = path.resolve(rootDir, process.env.ARCHIVE_DIR || 'archives');
const incomingDir = path.join(archiveDir, 'incoming');
const dbDir = path.join(rootDir, 'db');
const dbPath = path.join(dbDir, 'krasty.db');
const port = Number(process.env.PORT || 3000);
const isProduction = process.env.NODE_ENV === 'production';
const secretKey = process.env.SECRET_KEY;
const syncToken = process.env.SYNC_TOKEN;
const nodeRole = process.env.NODE_ROLE || 'primary';
const nodeType = process.env.NODE_TYPE || 'local';

if (!secretKey || secretKey.length < 32) {
  throw new Error('SECRET_KEY debe definirse en el entorno y tener al menos 32 caracteres. Consulte .env.example.');
}
if (!syncToken || syncToken.length < 32) {
  throw new Error('SYNC_TOKEN debe definirse en el entorno y tener al menos 32 caracteres. Consulte .env.example.');
}

for (const directory of [dataDir, archiveDir, incomingDir, dbDir]) {
  fs.mkdirSync(directory, { recursive: true, mode: 0o700 });
}

if (Number(process.env.TRUST_PROXY || 0) > 0) app.set('trust proxy', Number(process.env.TRUST_PROXY));

app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'", "'unsafe-inline'", 'https://cdn.tailwindcss.com'],
      styleSrc: ["'self'", "'unsafe-inline'", 'https://cdnjs.cloudflare.com'],
      fontSrc: ["'self'", 'https://cdnjs.cloudflare.com', 'data:'],
      imgSrc: ["'self'", 'data:', 'https:'],
      frameSrc: ["'self'", 'https:'],
      connectSrc: ["'self'"],
    },
  },
  crossOriginEmbedderPolicy: false,
}));
app.use(express.json({ limit: '10mb' }));
app.use(cookieParser());

const allowedOrigins = String(process.env.ALLOWED_ORIGINS || '').split(',').map((value) => value.trim()).filter(Boolean);
app.use((req, res, next) => {
  const origin = req.headers.origin;
  if (origin && allowedOrigins.includes(origin)) {
    res.setHeader('Access-Control-Allow-Origin', origin);
    res.setHeader('Vary', 'Origin');
    res.setHeader('Access-Control-Allow-Credentials', 'true');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, X-Sync-Token');
  }
  if (req.method === 'OPTIONS') return res.status(204).end();
  return next();
});
app.use(express.static(path.join(rootDir, 'public'), { index: 'index.html', etag: true, maxAge: isProduction ? '1h' : 0 }));

const generalLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 600, standardHeaders: 'draft-7', legacyHeaders: false });
const authLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 10, standardHeaders: 'draft-7', legacyHeaders: false, message: { error: 'Demasiados intentos. Vuelva a intentarlo más tarde.' } });
app.use('/api', generalLimiter);

const db = new sqlite3.Database(dbPath);
db.serialize(() => {
  db.run('PRAGMA foreign_keys = ON');
  db.run('PRAGMA journal_mode = WAL');
  db.run('CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE NOT NULL, password TEXT NOT NULL, quota INTEGER NOT NULL DEFAULT 53687091200, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)');
  db.run('CREATE TABLE IF NOT EXISTS agents (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, name TEXT NOT NULL, avatar_url TEXT, prompt TEXT NOT NULL DEFAULT \'\', FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE)');
  db.run('CREATE TABLE IF NOT EXISTS chats (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, title TEXT, history TEXT NOT NULL DEFAULT \'[]\', timestamp TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE)');
});

function safeEqual(provided, expected) {
  if (typeof provided !== 'string' || typeof expected !== 'string') return false;
  const a = Buffer.from(provided);
  const b = Buffer.from(expected);
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

function requireSyncToken(req, res, next) {
  if (!safeEqual(req.header('x-sync-token'), syncToken)) return res.status(403).json({ error: 'No autorizado.' });
  return next();
}

function requireAuth(req, res, next) {
  const token = req.cookies.krasty_session;
  if (!token) return res.status(401).json({ error: 'Inicie sesión para continuar.' });
  try {
    req.user = jwt.verify(token, secretKey, { algorithms: ['HS256'] });
    return next();
  } catch {
    return res.status(401).json({ error: 'La sesión ha caducado o no es válida.' });
  }
}

function sessionCookieOptions() {
  return { httpOnly: true, secure: isProduction || process.env.COOKIE_SECURE === 'true', sameSite: process.env.COOKIE_SAME_SITE || 'lax', maxAge: 8 * 60 * 60 * 1000, path: '/' };
}

function allowedModelConfig(provider) {
  const config = {
    ollama: { endpoint: process.env.OLLAMA_API_URL || 'http://127.0.0.1:11434/api/generate', protocol: 'ollama' },
    lmstudio: { endpoint: process.env.LMSTUDIO_API_URL || 'http://127.0.0.1:1234/v1/chat/completions', protocol: 'openai' },
    llamacpp: { endpoint: process.env.LLAMACPP_API_URL || 'http://127.0.0.1:8080/v1/chat/completions', protocol: 'openai' },
    chutes: { endpoint: 'https://llm.chutes.ai/v1/chat/completions', protocol: 'openai', apiKey: process.env.CHUTES_API_KEY },
  };
  return config[provider];
}

app.get('/api/health', (req, res) => res.json({ status: 'ok', node: nodeType, role: nodeRole, writable: nodeRole === 'primary', version: '2.0.0-audited' }));

// El nodo de contingencia acepta snapshots, pero nunca reemplaza la base activa automáticamente.
// Esto evita corrupción y "split brain" cuando ambos nodos creen ser el primario.
app.post('/api/sync/upload', requireSyncToken, (req, res) => {
  const { snapshotBase64, sha256, createdAt, sourceNode } = req.body || {};
  if (typeof snapshotBase64 !== 'string' || !/^[a-f0-9]{64}$/i.test(sha256 || '')) return res.status(400).json({ error: 'Snapshot inválido.' });
  try {
    const payload = Buffer.from(snapshotBase64, 'base64');
    if (payload.length === 0 || payload.length > 50 * 1024 * 1024) return res.status(413).json({ error: 'El tamaño del snapshot no es válido.' });
    const digest = crypto.createHash('sha256').update(payload).digest('hex');
    if (!safeEqual(digest, sha256.toLowerCase())) return res.status(400).json({ error: 'La comprobación de integridad falló.' });
    const stamp = new Date(createdAt || Date.now()).toISOString().replace(/[:.]/g, '-');
    const cleanSource = String(sourceNode || 'unknown').replace(/[^a-zA-Z0-9_-]/g, '_').slice(0, 40);
    const target = path.join(incomingDir, `${stamp}_${cleanSource}_${digest.slice(0, 12)}.db`);
    const temporary = `${target}.tmp`;
    fs.writeFileSync(temporary, payload, { mode: 0o600 });
    fs.renameSync(temporary, target);
    fs.writeFileSync(`${target}.json`, JSON.stringify({ sha256: digest, createdAt, sourceNode: cleanSource, receivedAt: new Date().toISOString() }, null, 2), { mode: 0o600 });
    return res.status(201).json({ message: 'Snapshot recibido y verificado; pendiente de promoción manual.', file: path.basename(target) });
  } catch (error) {
    return res.status(500).json({ error: 'No se pudo guardar el snapshot.' });
  }
});

app.get('/api/chutes/models', requireAuth, async (req, res) => {
  if (!process.env.CHUTES_API_KEY) return res.status(503).json({ error: 'Chutes.ai no está configurado en este nodo.' });
  try {
    const response = await axios.get('https://llm.chutes.ai/v1/models', { headers: { Authorization: `Bearer ${process.env.CHUTES_API_KEY}` }, timeout: 10000 });
    return res.json(response.data.data || []);
  } catch {
    return res.status(502).json({ error: 'No se pudo consultar el catálogo de Chutes.ai.' });
  }
});

app.post('/api/auth/register', authLimiter, async (req, res) => {
  const username = String(req.body?.username || '').trim();
  const password = String(req.body?.password || '');
  if (!/^[a-zA-Z0-9_.-]{3,32}$/.test(username) || password.length < 12 || password.length > 128) {
    return res.status(400).json({ error: 'Usuario inválido o contraseña demasiado corta (mínimo 12 caracteres).' });
  }
  const hashedPassword = await bcrypt.hash(password, 12);
  db.run('INSERT INTO users (username, password) VALUES (?, ?)', [username, hashedPassword], function callback(err) {
    if (err) return res.status(409).json({ error: 'No se pudo crear la cuenta.' });
    return res.status(201).json({ id: this.lastID, username });
  });
});

app.post('/api/auth/login', authLimiter, (req, res) => {
  const username = String(req.body?.username || '').trim();
  const password = String(req.body?.password || '');
  db.get('SELECT id, username, password FROM users WHERE username = ?', [username], async (err, user) => {
    if (err || !user || !(await bcrypt.compare(password, user.password))) return res.status(401).json({ error: 'Credenciales no válidas.' });
    const token = jwt.sign({ sub: user.id, username: user.username }, secretKey, { algorithm: 'HS256', expiresIn: '8h', issuer: 'krasty-kebab' });
    return res.cookie('krasty_session', token, sessionCookieOptions()).json({ username: user.username });
  });
});

app.post('/api/auth/logout', requireAuth, (req, res) => res.clearCookie('krasty_session', sessionCookieOptions()).status(204).end());

app.post('/api/chat', requireAuth, async (req, res) => {
  const message = String(req.body?.message || '').trim();
  const provider = String(req.body?.provider || 'ollama');
  const model = String(req.body?.model || '').trim();
  if (!message || message.length > 12000 || !/^[a-zA-Z0-9_.:/-]{1,180}$/.test(model || 'default')) return res.status(400).json({ error: 'Solicitud de chat inválida.' });
  const chosen = allowedModelConfig(provider);
  if (!chosen) return res.status(400).json({ error: 'Proveedor no permitido.' });
  if (provider === 'chutes' && !chosen.apiKey) return res.status(503).json({ error: 'Chutes.ai no está configurado en el servidor.' });
  try {
    let response;
    if (chosen.protocol === 'ollama') {
      const result = await axios.post(chosen.endpoint, { model: model || 'llama3', prompt: message, stream: false }, { timeout: 120000 });
      response = result.data?.response;
    } else {
      const headers = chosen.apiKey ? { Authorization: `Bearer ${chosen.apiKey}` } : {};
      const result = await axios.post(chosen.endpoint, { model: model || 'local-model', messages: [{ role: 'user', content: message }] }, { headers, timeout: 120000 });
      response = result.data?.choices?.[0]?.message?.content;
    }
    if (!response) throw new Error('El modelo no devolvió contenido.');
    return res.json({ response });
  } catch (error) {
    return res.status(502).json({ error: 'El proveedor de IA no respondió correctamente.' });
  }
});

app.get('*', (req, res) => res.sendFile(path.join(rootDir, 'public', 'index.html')));

app.listen(port, '0.0.0.0', () => console.log(`Krasty Kebab Fortress (${nodeType}/${nodeRole}) escuchando en el puerto ${port}.`));
