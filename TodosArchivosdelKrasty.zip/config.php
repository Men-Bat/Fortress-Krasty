<?php
return [
    'app_name' => 'Krasty Kebab Test',
    'data_root' => '/home/ubuntu/krasty_xampp/.testdata',
    'app_secret' => '0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef',
    'first_admin_token' => 'token-inicial-de-prueba-seguro-123456789',
    'quota_bytes' => 50 * 1024 * 1024 * 1024,
    'cookie_secure' => false,
    'base_path' => '',
    'model' => ['enabled' => false, 'provider' => 'ollama', 'ollama_url' => 'http://127.0.0.1:11434/api/generate', 'default_model' => 'llama3.2', 'timeout_seconds' => 10],
    'secondary_backup_share' => '\\TEST\\KrastyBackups',
    'vault_passphrase' => 'frase-de-prueba-larga-para-validar-boveda-123456789',
];
