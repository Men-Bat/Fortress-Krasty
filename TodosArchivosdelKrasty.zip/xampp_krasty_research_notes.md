# Notas de investigación — Krasty XAMPP

## Fuentes consultadas

1. PHP Manual — `password_hash`: https://www.php.net/manual/en/function.password-hash.php
   - `password_hash()` crea hashes con algoritmos unidireccionales fuertes.
   - PHP recomienda permitir más de 60 bytes (p. ej. 255) para el campo de hash.
   - La sal se genera automáticamente; no se debe especificar manualmente.

2. Apache HTTP Server 2.4 — mod_rewrite: https://httpd.apache.org/docs/current/mod/mod_rewrite.html
   - `mod_rewrite` permite reescritura de rutas y se activa con `RewriteEngine On`.

3. Apache HTTP Server 2.4 — Redirecting and Remapping: https://httpd.apache.org/docs/current/rewrite/remapping.html
   - Las rutas de una aplicación pueden pasar por un controlador frontal; el uso de HTTPS debe configurarse con cuidado.
   - Si existe un host virtual HTTP dedicado, `Redirect` es el método más sencillo para redirigir a HTTPS.

4. Apache HTTP Server 2.4 — Dynamic mass virtual hosts: https://httpd.apache.org/docs/current/rewrite/vhosts.html
   - Los nombres de host no los resuelve Apache por sí solo; DNS debe resolverlos.
   - Para la necesidad del usuario se usará una ruta de aplicación `web.com/usuario/Krasty/`, no un host virtual por usuario.

5. Microsoft Learn — Task Scheduler: https://learn.microsoft.com/en-us/windows/win32/taskschd/task-scheduler-start-page
   - El Programador de tareas permite ejecutar de forma automática trabajos basados en horario, inicio de sesión o arranque.
   - Se usará para lanzar el script de respaldo del servidor XAMPP al segundo ordenador.

## Decisiones de simplificación

- La aplicación será PHP + SQLite para XAMPP, sin Node.js y sin servicios externos obligatorios.
- Las rutas serán `https://web.com/<usuario>/Krasty/` mediante `.htaccess` y un controlador PHP único.
- Los datos se almacenarán fuera de `htdocs`, en una carpeta de datos configurable.
- La copia secundaria usará una carpeta compartida SMB del segundo ordenador y `robocopy` ejecutado por el Programador de tareas de Windows.
- La tercera copia será un archivo cifrado que el administrador podrá subir a una bóveda web estática. La automatización de subida dependerá de si el proveedor ofrece WebDAV/SFTP; no se afirmará soporte donde no exista.
- No se elimina autenticación, hashes de contraseña, ni aislamiento por usuario. Esas protecciones quedan integradas y no requieren que el usuario las administre a diario.
